import {chromium} from '/workspace/cloud-onboarding/browser/node_modules/playwright/index.mjs';
import fs from 'node:fs/promises';
const out='/tmp/halfsword-roster-ratna-20261013';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-background-networking']});
try{
 const page=await browser.newPage({viewport:{width:1200,height:675},deviceScaleFactor:1});const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.addInitScript(()=>localStorage.setItem('gladiator-settings',JSON.stringify({pixel:false,sound:false,trail:false,blood:true,difficulty:'normal',skill:'0.3',fpsCap:true})));
 await page.route('**/@vite/client',r=>r.fulfill({contentType:'application/javascript',body:'// no capture HMR'}));
 await page.goto('http://127.0.0.1:4182/?stage=sluice&foe=ratna&weapon=sain&foeWeapon=rapier',{waitUntil:'networkidle',timeout:60000});
 await page.waitForFunction(()=>window.game?.enemy?.groups?.head,null,{timeout:60000});await page.locator('#btnStart').click();
 await page.waitForFunction(()=>game.state==='fight'&&game.stats.simTime>=1.5,null,{timeout:120000});
 await page.locator('#btnPause').click();await page.addStyleTag({content:'.overlay{visibility:hidden!important}'});await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 await page.locator('#game').screenshot({path:out+'/sluice-game.png'});
 const info=await page.evaluate(()=>({stage:game.stage,render:game.renderInfo(),camera:game.camera.position.toArray(),enemy:game.enemy.name,foeWeapon:game.enemy.weapon.id}));
 await page.evaluate(()=>{game.freeCam=true;game.camera.position.set(-7,4.5,7);game.camera.lookAt(0,2.5,0);});
 await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 await page.locator('#game').screenshot({path:out+'/sluice-vista.png'});
 await page.evaluate(()=>{game.camera.position.set(-9,3.1,0);game.camera.lookAt(0,2.9,0);});
 await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 await page.locator('#game').screenshot({path:out+'/bear-front.png'});
 await page.evaluate(()=>{game.camera.position.set(-3,5.25,.12);game.camera.lookAt(0,5.1,0);});
 await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 await page.locator('#game').screenshot({path:out+'/bear-face.png'});
 await fs.writeFile(out+'/screenshots.json',JSON.stringify({info,errors,method:'Unedited actual native canvas, pause menu hidden for capture. Game view uses ordinary camera after1.5s; vista uses inspection camera in same scene. No character/physics mutations.'},null,2));
 if(info.foeWeapon!=='rapier')throw Error('Wrong enemy weapon');if(errors.length)throw Error(errors.join('\n'));console.log(JSON.stringify(info));
}finally{await browser.close();}
