from pathlib import Path
import json,hashlib,tarfile,sys
root=Path('/workspace/halfsword-codex');ev=Path('/tmp/halfsword-roster-ratna-20261013');delivery=Path('/tmp/halfsword-sluice-20261013/revision3')
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reports={'obstacle':ev/'obstacle.json','stage':ev/'scene-report.json','appearance':Path('/tmp/halfsword-ratna-v3-20261013/appearance-native.json')}
data={k:read(p) for k,p in reports.items()};assert all(v['pass'] for v in data.values())
for k in ['local','public']:
 p=delivery/k/'report.json'
 if p.exists():reports[k]=p;data[k]=read(p);assert data[k]['pass'] and not data[k]['errors']
limits=['Reference-based procedural stone sculpture, not a photo scan or exact likeness guarantee.','Monkey is a static chest decoration; extreme allowed neck poses may overlap it by up to33.3mm.','Native three AI approaches are not all-weapon or win-rate coverage.','Mobile Chromium emulation is not physical-phone performance or user aesthetic approval.']
summary={'base':'af089dbbf270ede341cfe8a62f22f88721ac399a','name':'라트나 위라세타쿤','title':'습지 안내인','weapon':'rapier','look':'v3','sources':{},'reports':{k:{'sha256':sha(p)} for k,p in reports.items()},'stage':{k:data['stage']['runs'][0][k] for k in ['triangles','calls','owned','disposed']},'obstacleChecks':len(data['obstacle']['checks']),'nativeApproaches':[{k:r[k] for k in ['seed','minDistance','maxSide','pelvisInsideStone']} for r in data['obstacle']['runs']],'limits':limits}
for name in ['src/outfit_ratna.js','src/looks.js','src/characters_expansion.js','src/stage_sluice_bear.js','src/arena_obstacle.js','tools/browser/sluice_delivery_20261013.mjs','public/sluice.html']:summary['sources'][name]=sha(root/name)
for k in ['local','public']:
 if k not in data:continue
 r=data[k];summary[k]={'pass':True,'completedUTC':r['completedUTC'],'requests':len(r['requests']),'uniqueFiles':len({x['name'] for x in r['requests']}),'errors':0,'toolHash':r['toolHash'],'enemy':r['flow']['final']['terrain'][1]}
f=root/'docs/content/ratna_sunbear_refinement_checks_20261013.json';f.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
if len(sys.argv)>1:
 pub=data['public'];assert pub['buildManifest']==data['local']['buildManifest']
 archive=root/'docs/content/ratna_sunbear_refinement_evidence_20261013.tar.xz'
 with tarfile.open(archive,'w:xz') as t:
  for k,p in reports.items():t.add(p,arcname=k+'.json')
  for n in ['screenshots.json','capture-stage.mjs','capture-character.mjs','record.py','exchange-publication.json','build.log','pages.json','portrait/character-report.json','references.json']:t.add(ev/n,arcname=n)
 receipt={'status':'public_verified','gameCommit':pub['head'],'pages':'https://github.com/yoonjl-svg/halfsword-codex/actions/runs/'+sys.argv[1],'landing':'https://yoonjl-svg.github.io/halfsword-codex/sluice.html','local':summary['local'],'public':summary['public'],'archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)},'limits':limits}
 (root/'docs/content/ratna_sunbear_refinement_release.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
 status=f'`{pub["head"][:7]}` 공개 완료. 로컬·공개 모바일 진입/터치 공격·웅덩이 이동/재시작, 공개{summary["public"]["uniqueFiles"]}파일 해시 일치·오류0.'
 for name in ['docs/content/ratna_sunbear_refinement_20261013.md','docs/codex_team/README.md','docs/codex_team/ACTIVE_PLAN.md','docs/dev_exchange/notes/2026-10-14.md']:
  p=root/name;p.write_text(p.read_text().replace('라트나 v3 공개 검증 진행 중.',status))
print(json.dumps(summary,ensure_ascii=False))
