// These outdoor/detail stages share the game's master bus, noise buffer and
// camera-relative positioning. Detail sounds are driven by visible motion,
// never by wall-clock timers or a second combat-event scheduler.
export const STAGE_DETAIL_PROFILES = Object.freeze({
  clothRustle: { stage: 'loggia', duration: 1.25, gain: 0.024, gap: 5 },
  riggingCreak: { stage: 'corsair', duration: 1.8, gain: 0.025, gap: 6 },
  waterLap: { stage: 'corsair', duration: 1.5, gain: 0.021, gap: 4 },
  groveRustle: { stage: 'sacred_grove', duration: 1.65, gain: 0.020, gap: 5 },
  paperRustle: { stage: 'sacred_grove', duration: 0.9, gain: 0.016, gap: 7 },
  gullCall: { stage: 'corsair', duration: 2.15, gain: 0.085, gap: 24 },
  lakeIceBoom: { stage: 'frozen_bay', duration: 3.5, gain: 0.055, gap: 26 },
  frozenPierCreak: { stage: 'frozen_bay', duration: 1.9, gain: 0.030, gap: 24 },
  springDrip: { stage: 'qinglan', duration: 0.65, gain: 0.028, gap: 2 },
  cliffBird: { stage: 'qinglan', duration: 1.25, gain: 0.055, gap: 26 },
  // 잠든 습지 (샛별 저장소 origin/main 325a5c38 의 소리 셋을 옮김 — docs/import/sluice_port_2026-10-14.md)
  sluiceDrip: { stage: 'sluice', duration: 0.7, gain: 0.042, gap: 2.5 },
  jungleRustle: { stage: 'sluice', duration: 2.0, gain: 0.025, gap: 8 },
  jungleBird: { stage: 'sluice', duration: 1.7, gain: 0.043, gap: 30 },
  // 소금 사막 (샛별 저장소 origin/main db729604 의 우물 고리 소리를 옮김 — docs/import/salt_desert_port_2026-10-14.md).
  //  표 자리 = 난수 씨앗(9127 + 자리 × 311 + 변형 × 101)이라 습지 셋 뒤(자리 13 — 샛별 표와 같은 자리)에 붙인다: 있던 세부음 씨앗은 그대로
  caravanRing: { stage: 'dayr', duration: 1.1, gain: 0.025, gap: 22 },
  // 철불 절벽 (샛별 저장소 origin/main 7684c732 의 간판 이음매 삐걱 소리를 옮김 — docs/import/ironcliff_port_2026-10-14.md, 값 그대로).
  //  표 끝(자리 14)에 붙여 있던 세부음 씨앗(자리 0~13)은 하나도 안 바뀐다. 샛별 표에서는 자리 15(그쪽 14 는 화산섬 etnaCrust)라 변형 셋의 잡음 결은 샛별 판과 다르다(합성 꼴·길이·세기는 같다).
  //  나중에 화산섬(용암 무대)의 etnaCrust 는 이 줄 뒤(자리 15)에 붙인다
  dunhuangWood: { stage: 'dunhuang', duration: 1.65, gain: 0.023, gap: 24 },
  // 화산섬 (샛별 저장소 origin/main 7684c732 의 굳은 껍질 소리를 옮김 — docs/import/volcano_port_2026-10-14.md). 표 끝(자리 15)에 붙여 있던 세부음 씨앗(자리 0~14)은 그대로.
  //  샛별 표에서는 자리 14(그쪽 15 는 철불 절벽 dunhuangWood)라 변형 셋의 잡음 결은 샛별 판과 다르다(합성 꼴·길이·세기는 같다)
  etnaCrust: { stage: 'etna', duration: 1.6, gain: 0.032, gap: 20 },
  wetlandThunder: { stage: 'sluice', nightOnly: true, duration: 3.8, gain: .24, gap: 5 },
  courtyardCloth: { stage: 'courtyard', duration: 1.25, gain: .024, gap: 5 },
  // 봉인의 중정 우물 둘 (10/17 디자인 리뷰 고칠 목록 7 — 청람잔도 샘 물방울 · 소금 사막 우물 고리를 다시 쓰던 것을 이 무대만의 소리로): 깊은 우물에 떨어지는 물방울의 울림 ·
  //  돌풍 끝에 두레박이 돌 가장자리에 닿는 둔한 나무 소리와 물 출렁임이 우물 아래로 되울림. 표 자리(씨앗)는 그대로 — 길이만 울림 꼬리에 맞춤 [사장님 확인 전]
  courtyardDrip: { stage: 'courtyard', duration: .95, gain: .018, gap: 8 },
  courtyardRing: { stage: 'courtyard', duration: 1.1, gain: .02, gap: 8 },
});
// 봉인의 중정 돌풍 (10/17 목록 7): 무대가 돌풍을 시작할 때 'courtyardGust' { duration } 를 보낸다 — 세부음(목소리 둘 · 간격 규칙)이 아니라 바탕 바람의 한 겹을 키운다.
//  바탕 대비 돌풍 한가운데 약 +6 dB (low → 1 · 오르는 시간 = 길이 × rise, 내려오는 때 = 길이 × fallAt) [사장님 확인 전]
export const COURTYARD_GUST = Object.freeze({ low: 0.2, rise: 0.18, fallAt: 0.55, fall: 0.2 });

export const WETLAND_THUNDER_VARIANTS = Object.freeze([
  Object.freeze({ name: 'short', duration: 1.8 }),
  Object.freeze({ name: 'rolling', duration: 3.8 }),
  Object.freeze({ name: 'extended', duration: 6.2 }),
]);

const detailBase = stage => ['loggia_night','corsair_night','sacred_grove_night','sluice_night','etna_night','qinglan_night','dunhuang_night','dayr_night'].includes(stage) ? stage.slice(0,-6) : stage;
export const hasStageDetails = (id) => {const stage=detailBase(id);return stage === 'courtyard' || stage === 'loggia' || stage === 'corsair' || stage === 'sacred_grove' || stage === 'frozen_bay' || stage === 'qinglan' || stage === 'sluice' || stage === 'dayr' || stage === 'dunhuang' || stage === 'etna';};
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const TAU = Math.PI * 2;

/** Deterministic material friction and distant bird call, not impact cues.
 * rng is the existing sound.js makeRng. Returned mono PCM is also used by the
 * offline review renderer; no recordings, network assets or sample imports.
 */
export function synthStageDetail(kind, sr, rng, variant = 1) {
  const profile = STAGE_DETAIL_PROFILES[kind];
  if (!profile || !Number.isFinite(sr) || sr < 8000) return new Float32Array(0);
  // 중정 천 소리는 있던 천 합성을 다시 쓴다 — 표 끝에 더해 기존 무대들의 씨앗 차례는 그대로 (샛별 저장소 10/17). 우물 둘은 10/17 에 이 무대만의 합성으로(아래)
  kind = ({courtyardCloth:'clothRustle'})[kind] ?? kind;
  const thunder = kind === 'wetlandThunder' ? WETLAND_THUNDER_VARIANTS[variant] ?? WETLAND_THUNDER_VARIANTS[1] : null;
  const out = new Float32Array(Math.ceil((thunder?.duration ?? profile.duration) * sr));
  if (kind === 'wetlandThunder') {
    // Three different envelopes, not just three noise seeds. The middle form
    // preserves the original rolling sound; the long form swells repeatedly.
    if (thunder.name !== 'rolling') {
      const short=thunder.name==='short',shift=rng(),starts=short?[0]:[0,.82+shift*.22,1.95+shift*.18,3.25+shift*.28];
      const a=1-Math.exp(-TAU*(short?155:85)/sr),b=1-Math.exp(-TAU*(short?1050:480)/sr);
      let low=0,mid=0,peak=0;
      for(let i=0;i<out.length;i++){
        const t=i/sr,n=rng()*2-1;low+=a*(n-low);mid+=b*(n-mid);
        let body=0,crackle=0;
        for(let j=0;j<starts.length;j++){
          const age=t-starts[j];if(age<0)continue;
          const weight=short?1:1-j*.14,rise=1-Math.exp(-age/(short?.028:.10));
          body+=weight*rise*Math.exp(-age/(short?.42:1.1));
          crackle+=weight*rise*Math.exp(-age/(short?.14:.32));
        }
        const tail=Math.min(1,(out.length-1-i)/(sr*(short?.22:.65)));
        const roll=short?1:.64+.36*Math.sin(t*4.1+shift*3+.3*Math.sin(t*7))**2;
        out[i]=tail*(2.8*low*body*roll+(short?.32:.16)*(mid-low)*crackle);
        peak=Math.max(peak,Math.abs(out[i]));
      }
      if(peak>.65)for(let i=0;i<out.length;i++)out[i]*=.65/peak;
      return out;
    }
    let low=0,mid=0;const a=1-Math.exp(-TAU*110/sr),b=1-Math.exp(-TAU*620/sr),shift=rng()*2;
    for(let i=0;i<out.length;i++){
      const t=i/sr,n=rng()*2-1;low+=a*(n-low);mid+=b*(n-mid);
      const rise=1-Math.exp(-t/.055),tail=Math.min(1,(out.length-1-i)/(sr*.45));
      const roll=.6+.4*Math.sin(t*6.2+shift)**2;
      out[i]=rise*tail*(2.6*low*roll*Math.exp(-t/1.35)+.24*(mid-low)*Math.exp(-t/.30));
    }
    return out;
  }
  if (kind === 'etnaCrust') {
    // 화산섬: 먼 굳은 용암 껍질이 부서지는 소리 — 걸러 낮춘 금 가는 소리와 짧게 흘러내리는 알갱이 (샛별 원문 그대로).
    //  계속되는 불 굉음·폭발·싸움 소리 같은 순간음은 없다
    let low = 0, body = 0;
    for (let i = 0; i < out.length; i++) {
      const t = i / sr, n = rng() * 2 - 1;
      low += (1 - Math.exp(-TAU * 560 / sr)) * (n - low);
      body += (1 - Math.exp(-TAU * 115 / sr)) * (n - body);
      const attack = 1 - Math.exp(-t / 0.008), tail = Math.min(1, (out.length - 1 - i) / (sr * 0.12));
      const grit = Math.max(0, Math.sin(t * 39) + Math.sin(t * 71) * 0.4);
      out[i] = tail * attack * (0.6 * body * Math.exp(-t / 0.28) + 0.16 * low * grit * Math.exp(-t / 0.4));
    }
    return out;
  }
  if (kind === 'dunhuangWood') {
    // 철불 절벽: 처마 밑 글씨 없는 나무 간판의 마른 이음매가 흔들림 끝에서 버티며 내는 짧은 삐걱 (샛별 원문 그대로 — 부드럽고 고르지 않은 두 번의 끌림·미끄러짐)
    // A dry eave/sign joint strains with a visible sway. Two soft, irregular
    // stick/slip folds keep this short cue separate from a tonal wind bed.
    let low = 0, grain = 0, phase = 0;
    const variation = rng(), pitch = 0.94 + variation * 0.12;
    const lowA = 1 - Math.exp(-TAU * 140 / sr), grainA = 1 - Math.exp(-TAU * 820 / sr);
    for (let i = 0; i < out.length; i++) {
      const t = i / sr, u = i / (out.length - 1), n = rng() * 2 - 1;
      low += lowA * (n - low); grain += grainA * (n - grain);
      const fold = Math.sin(Math.PI * u) ** 2;
      const strain = 0.15 + 0.85 * Math.sin(t * (6.1 + variation) + 0.32 * Math.sin(t * 17)) ** 4;
      phase += TAU * (133 + 23 * Math.sin(Math.PI * u) + 7 * Math.sin(t * 29)) * pitch / sr;
      out[i] = fold * strain * (0.35 * (grain - low) + 0.033 * Math.sin(phase)
        + 0.011 * Math.sin(phase * 2.17));
    }
    return out;
  }
  if (kind === 'courtyardDrip') {
    // 봉인의 중정: 6 m 아래 우물물에 떨어지는 물방울 — 샘 물방울보다 낮게 오르는 거품 소리 · 우물 통의 낮은 울림(140 Hz) · 돌 벽에 0.11 s 마다 되울림 넷
    const pitch = 0.92 + rng() * 0.1, taps = [[0, 1], [0.11, 0.46], [0.225, 0.24], [0.345, 0.12], [0.47, 0.06]];
    const dry = new Float32Array(Math.ceil(0.32 * sr));
    let phase = 0, splash = 0;
    const a = 1 - Math.exp(-TAU * 1500 / sr);
    for (let i = 0; i < dry.length; i++) {
      const t = i / sr;
      phase += TAU * (520 + 300 * (1 - Math.exp(-t / 0.05))) * pitch / sr;
      splash += a * (rng() * 2 - 1 - splash);
      const envelope = (1 - Math.exp(-t / 0.003)) * Math.exp(-t / 0.045);
      dry[i] = 0.3 * Math.sin(phase) * envelope + 0.07 * splash * Math.exp(-t / 0.02)
        + 0.09 * Math.sin(TAU * 140 * pitch * t) * (1 - Math.exp(-t / 0.01)) * Math.exp(-t / 0.18);
    }
    for (const [delay, gain] of taps) {
      const off = Math.floor(delay * sr);
      let low = 0; const lowA = 1 - Math.exp(-TAU * (delay ? 1100 : 9000) / sr); // 되울림일수록 어둡게
      for (let i = 0; i < dry.length && off + i < out.length; i++) { low += lowA * (dry[i] - low); out[off + i] += gain * low; }
    }
    for (let i = 0; i < out.length; i++) out[i] *= Math.min(1, (out.length - 1 - i) / (sr * 0.08));
    return out;
  }
  if (kind === 'courtyardRing') {
    // 봉인의 중정: 돌풍 끝에 두레박이 우물 돌 가장자리에 닿는 둔한 나무 소리(180 · 310 · 470 Hz 빨리 사그라짐)와 짧은 물 출렁임이
    //  우물 아래로 0.14 · 0.29 · 0.45 s 에 되울린다 — 소금 사막의 맑은 쇠고리(670 · 1093 · 1771 Hz)와 다른 소리
    const pitch = 0.95 + rng() * 0.1, dry = new Float32Array(Math.ceil(0.55 * sr));
    let thud = 0, slosh = 0, sloshLow = 0;
    const thudA = 1 - Math.exp(-TAU * 900 / sr), sA = 1 - Math.exp(-TAU * 820 / sr), sLowA = 1 - Math.exp(-TAU * 260 / sr);
    for (let i = 0; i < dry.length; i++) {
      const t = i / sr, n = rng() * 2 - 1;
      thud += thudA * (n - thud); slosh += sA * (n - slosh); sloshLow += sLowA * (slosh - sloshLow);
      const attack = 1 - Math.exp(-t / 0.0025);
      const knock = 0.26 * Math.sin(TAU * 180 * pitch * t) * Math.exp(-t / 0.06) + 0.13 * Math.sin(TAU * 310 * pitch * t) * Math.exp(-t / 0.04)
        + 0.06 * Math.sin(TAU * 470 * pitch * t) * Math.exp(-t / 0.025) + 0.16 * thud * Math.exp(-t / 0.012);
      const st = Math.max(0, t - 0.05), wave = (1 - Math.exp(-st / 0.05)) * Math.exp(-st / 0.22) * (0.6 + 0.4 * Math.sin(st * 23));
      dry[i] = attack * knock + 0.09 * (slosh - sloshLow) * wave;
    }
    for (const [delay, gain] of [[0, 1], [0.14, 0.38], [0.29, 0.19], [0.45, 0.09]]) {
      const off = Math.floor(delay * sr);
      let low = 0; const lowA = 1 - Math.exp(-TAU * (delay ? 900 : 9000) / sr);
      for (let i = 0; i < dry.length && off + i < out.length; i++) { low += lowA * (dry[i] - low); out[off + i] += gain * low; }
    }
    for (let i = 0; i < out.length; i++) out[i] *= Math.min(1, (out.length - 1 - i) / (sr * 0.1));
    return out;
  }
  if (kind === 'caravanRing') {
    // 소금 사막: 우물 줄 끝의 작은 쇠고리가 흔들림 끝에서 쇠말뚝에 닿는 소리 (샛별 원문 그대로 — 670·1093·1771 Hz 감쇠 부분음)
    // A small iron ring touching its peg: dry, damped and irregular partials.
    const pitch = 0.96 + rng() * 0.08;
    for (let i = 0; i < out.length; i++) {
      const t = i / sr, attack = 1 - Math.exp(-t / 0.0018);
      const tail = Math.min(1, (out.length - 1 - i) / (sr * 0.08));
      out[i] = attack * tail * (0.23 * Math.sin(TAU * 670 * pitch * t) * Math.exp(-t / 0.095)
        + 0.10 * Math.sin(TAU * 1093 * pitch * t) * Math.exp(-t / 0.057)
        + 0.06 * Math.sin(TAU * 1771 * pitch * t) * Math.exp(-t / 0.03)
        + 0.035 * (rng() * 2 - 1) * Math.exp(-t / 0.009));
    }
    return out;
  }
  if (kind === 'jungleBird') {
    // 잠든 습지: 멀리서 드문드문 우는 둥근 숲새 소리 (녹음이 아닌 합성). 두 숨 사이에 조용한 틈, 계속 우는 합창이 아니다.
    const pitch = 0.94 + rng() * 0.12;
    for (const [start, duration, base] of [[0.06, 0.27, 1180], [0.62, 0.36, 990]]) {
      let phase = 0;
      const count = Math.floor(duration * sr), offset = Math.floor(start * sr);
      for (let i = 0; i < count; i++) {
        const u = i / count, t = i / sr;
        phase += TAU * (base + 210 * Math.sin(Math.PI * u) - 80 * u + 15 * Math.sin(t * 38)) * pitch / sr;
        out[offset + i] = Math.sin(Math.PI * u) ** 2 * (0.26 * Math.sin(phase) + 0.022 * Math.sin(phase * 2) + 0.006 * (rng() * 2 - 1));
      }
    }
    return out;
  }
  if (kind === 'springDrip' || kind === 'cliffBird' || kind === 'sluiceDrip') {
    const pitch = 0.94 + rng() * 0.12;
    if (kind === 'springDrip' || kind === 'sluiceDrip') {
      // One visible drop entering the small rock basin: a quickly damped
      // rising bubble and tiny splash, without a sustained bell or rain bed.
      let phase = 0, splash = 0;
      const a = 1 - Math.exp(-TAU * 2300 / sr);
      for (let i = 0; i < out.length; i++) {
        const t = i / sr, tail = Math.min(1, (out.length - 1 - i) / (sr * 0.05));
        phase += TAU * (840 + 520 * (1 - Math.exp(-t / 0.045))) * pitch * (kind === 'sluiceDrip' ? 0.78 : 1) / sr; // 수문 물방울은 조금 낮게
        splash += a * (rng() * 2 - 1 - splash);
        const envelope = (1 - Math.exp(-t / 0.0025)) * Math.exp(-t / 0.038);
        out[i] = tail * (0.31 * Math.sin(phase) * envelope
          + 0.075 * splash * (1 - Math.exp(-t / 0.001)) * Math.exp(-t / 0.017));
      }
    } else {
      // Two light, distant small-bird syllables at the visible bird's position.
      // Short breaths and rounded contours avoid the long coastal gull cry.
      for (const [start, duration, base] of [[0.025, 0.13, 2350], [0.27, 0.17, 2630]]) {
        let phase = 0;
        const count = Math.floor(duration * sr), offset = Math.floor(start * sr);
        for (let i = 0; i < count; i++) {
          const u = i / count, t = i / sr, envelope = Math.sin(Math.PI * u) ** 2;
          phase += TAU * (base + 480 * Math.sin(Math.PI * u) + 45 * Math.sin(t * 75)) * pitch / sr;
          out[offset + i] = envelope * (0.25 * Math.sin(phase) + 0.014 * (rng() * 2 - 1));
        }
      }
    }
    return out;
  }
  if (kind === 'lakeIceBoom' || kind === 'frozenPierCreak') {
    const variation = rng(), pitch = 0.91 + variation * 0.18;
    let low = 0, body = 0, air = 0, phase = 0, chirp = 0, peak = 0;
    const lowA = 1 - Math.exp(-TAU * 105 / sr), bodyA = 1 - Math.exp(-TAU * 680 / sr);
    const airA = 1 - Math.exp(-TAU * 1900 / sr);
    for (let i = 0; i < out.length; i++) {
      const t = i / sr, u = i / (out.length - 1), white = rng() * 2 - 1;
      low += lowA * (white - low); body += bodyA * (white - body); air += airA * (white - air);
      let sample;
      if (kind === 'lakeIceBoom') {
        // Distant sheet flex: broad, low modes arrive under a small, brief
        // dispersive overtone. No sharp weapon-like attack or long pitch dive.
        const bloom = (1 - Math.exp(-t / 0.07)) * Math.exp(-t / 0.78);
        const modes = 0.18 * Math.sin(TAU * 49 * pitch * t)
          + 0.09 * Math.sin(TAU * 78.3 * pitch * t + 0.16 * Math.sin(t * 8))
          + 0.05 * Math.sin(TAU * 123.7 * pitch * t);
        const ct = Math.max(0, t - 0.035), window = ct < 0.31 ? Math.sin(Math.PI * ct / 0.31) ** 2 : 0;
        phase += TAU * (360 + 420 * Math.exp(-ct / 0.065)) * pitch / sr;
        chirp += TAU * (590 + 490 * Math.exp(-ct / 0.045)) * pitch / sr;
        sample = bloom * (modes + 0.8 * low + 0.09 * body)
          + window * (0.030 * Math.sin(phase) + 0.012 * Math.sin(chirp) + 0.040 * (air - body));
      } else {
        // Short stick/slip of dry timber and taut rope, with an uneven rasp
        // and only weak pitch: no dock water or bell-like sustained note.
        const fold = Math.sin(Math.PI * u) ** 2;
        const strain = 0.32 + 0.68 * Math.sin(t * (8 + variation * 2) + 0.7 * Math.sin(t * 19)) ** 2;
        phase += TAU * (116 + 24 * Math.sin(u * Math.PI) + 5 * Math.sin(t * 21)) * pitch / sr;
        sample = fold * strain * (0.32 * (body - low) + 0.045 * Math.sin(phase)
          + 0.022 * Math.sin(phase * 2.13) + 0.015 * Math.sin(phase * 3.71));
      }
      // Smooth the finite tail, including when rendered at a different rate.
      out[i] = sample * Math.min(1, (1 - u) / 0.12);
      peak = Math.max(peak, Math.abs(out[i]));
    }
    if (peak > 0.45) for (let i = 0; i < out.length; i++) out[i] *= 0.45 / peak;
    return out;
  }
  if (kind === 'gullCall') {
    // Two short, rough calls followed by a falling cry. This is a procedural
    // coastal-bird interpretation, not a recording of a particular species.
    const pitch = 0.94 + rng() * 0.12;
    for (const [start, duration, strength] of [[0.03, 0.24, 0.55], [0.39, 0.29, 0.68], [0.86, 1.12, 1]]) {
      let phase = 0, breath = 0;
      const count = Math.floor(duration * sr), offset = Math.floor(start * sr);
      for (let j = 0; j < count && offset + j < out.length; j++) {
        const u = j / count, t = j / sr;
        const rise = 280 * Math.sin(Math.PI * Math.min(1, u * 4));
        const frequency = (850 + rise - 360 * u + 20 * Math.sin(t * 52)) * pitch;
        phase += TAU * frequency / sr;
        breath += 0.35 * (rng() * 2 - 1 - breath);
        const envelope = Math.min(1, u / 0.07) * (1 - u) ** 0.7 * Math.min(1, (1 - u) / 0.04);
        const roughness = 0.86 + 0.14 * Math.sin(t * 91);
        out[offset + j] += strength * envelope * (roughness * (0.25 * Math.sin(phase) + 0.09 * Math.sin(phase * 2) + 0.035 * Math.sin(phase * 3)) + 0.045 * breath);
      }
    }
    return out;
  }
  const cutoff = { clothRustle: 1600, riggingCreak: 800, waterLap: 950, groveRustle: 2100, paperRustle: 2600, jungleRustle: 1250 }[kind];
  const a = 1 - Math.exp(-TAU * cutoff / sr);
  const lowA = 1 - Math.exp(-TAU * 170 / sr);
  let filtered = 0, low = 0, phase = 0, peak = 0;
  const variation = rng();
  for (let i = 0; i < out.length; i++) {
    const t = i / sr, u = i / (out.length - 1);
    filtered += a * (rng() * 2 - 1 - filtered);
    low += lowA * (filtered - low);
    const envelope = Math.sin(Math.PI * u) ** 2;
    // Gentle overlapping creases, without a sharp attack that could suggest a hit.
    const folds = 0.52 + 0.48 * Math.sin(t * (19 + variation * 9) + Math.sin(t * 7)) ** 2;
    let sample = (filtered - low) * folds * 0.6;
    if (kind === 'riggingCreak') {
      phase += TAU * (145 + 32 * Math.sin(u * Math.PI) + 6 * Math.sin(t * 17)) / sr;
      sample = sample * 0.36 + (Math.sin(phase) + 0.25 * Math.sin(phase * 2.07)) * 0.12 * folds;
    } else if (kind === 'waterLap') {
      phase += TAU * (410 - 170 * u + 30 * Math.sin(t * 13)) / sr;
      sample = filtered * 0.45 + Math.sin(phase) * 0.028 * folds;
    } else if (kind === 'paperRustle') {
      sample *= 0.5 + 0.5 * Math.sin(t * 43) ** 2;
    }
    out[i] = sample * envelope;
    peak = Math.max(peak, Math.abs(out[i]));
  }
  if (peak > 0.45) for (let i = 0; i < out.length; i++) out[i] *= 0.45 / peak;
  return out;
}

export class StageDetailSound {
  constructor(sound, makeRng) {
    this.sound = sound;
    this.makeRng = makeRng;
    this.stage = detailBase(sound.stage);
    this.stageId = sound.stage;
    this.paused = !!sound._stagePaused;
    this.voices = new Set();
    this.buffers = new Map(); // At most three variants for each detail kind.
    this.last = new Map();
    this.lastAny = -Infinity;
    this.ambient = null;
    this.stats = { accepted: 0, rejected: 0, ended: 0, stopped: 0, peakVoices: 0, last: null };
  }

  setStage(stage) {
    this.stopVoices();
    this.stopAmbient();
    this.stage = detailBase(stage);
    this.stageId = stage;
    this.buffers.clear();
    this.last.clear();
    this.lastAny = -Infinity;
  }

  setPaused(paused) {
    if (this.paused === !!paused) return;
    this.paused = !!paused;
    if (this.paused) this.stopVoices();
    const c = this.sound.ctx;
    if (this.ambient) {
      const gain = this.ambient.out.gain;
      gain.cancelScheduledValues(c.currentTime);
      gain.setTargetAtTime(this.paused ? 0 : 1, c.currentTime, this.paused ? 0.025 : 0.22);
    }
  }

  stopVoices() {
    const c = this.sound.ctx;
    for (const voice of this.voices) {
      voice.gain.gain.cancelScheduledValues(c.currentTime);
      voice.gain.gain.setTargetAtTime(0, c.currentTime, 0.01);
      voice.source.stop(c.currentTime + 0.055);
      this.stats.stopped++;
    }
    this.voices.clear();
  }

  stopAmbient() {
    const old = this.ambient;
    if (!old) return;
    const t = this.sound.ctx.currentTime;
    old.out.gain.cancelScheduledValues(t);
    old.out.gain.setTargetAtTime(0, t, 0.045);
    for (const source of old.nodes) source.stop(t + 0.3);
    this.ambient = null;
  }

  ambience() {
    if (this.ambient) return this.ambient;
    const sound = this.sound, c = sound.ctx;
    const out = c.createGain();
    out.gain.value = 0;
    if (!this.paused) out.gain.setTargetAtTime(1, c.currentTime + 0.1, 0.8);
    out.connect(sound.master);
    const nodes = [], connections = [out];
    const addNoise = ({ rate = 1, type = 'bandpass', frequency, gain, lfo, depth, pan = 0, ceiling = 1800, bus = out }) => {
      const src = c.createBufferSource();
      src.buffer = sound._noiseBuf(); src.loop = true; src.playbackRate.value = rate;
      const filter = c.createBiquadFilter(); filter.type = type; filter.frequency.value = frequency; filter.Q.value = 0.65;
      const top = c.createBiquadFilter(); top.type = 'lowpass'; top.frequency.value = ceiling; top.Q.value = 0.5;
      const volume = c.createGain(); volume.gain.value = gain;
      src.connect(filter).connect(top).connect(volume);
      const panner = c.createStereoPanner?.();
      if (panner) { panner.pan.value = pan; volume.connect(panner).connect(bus); connections.push(panner); }
      else volume.connect(bus);
      connections.push(src, filter, top, volume); nodes.push(src);
      const mod = c.createOscillator(), amount = c.createGain();
      mod.frequency.value = lfo; amount.gain.value = depth;
      mod.connect(amount).connect(volume.gain);
      nodes.push(mod); connections.push(mod, amount);
    };
    let gust = null;
    if (this.stage === 'courtyard') {
      addNoise({rate:.8,frequency:530,gain:.0025,lfo:.049,depth:.0011,ceiling:1550,pan:.15});
      addNoise({rate:.72,frequency:1200,gain:.001,lfo:.071,depth:.0004,ceiling:2200,pan:-.2});
      // 돌풍 겹 (10/17 목록 7): 거친 바람(700 Hz)과 모래 스침(2.6 kHz) — 평소 COURTYARD_GUST.low 로 낮게 깔렸다가 무대가 알린 돌풍에 맞춰 커진다(gust)
      gust = c.createGain(); gust.gain.value = COURTYARD_GUST.low; gust.connect(out); connections.push(gust);
      addNoise({rate:.76,frequency:700,gain:.0076,lfo:.13,depth:.0018,ceiling:1700,pan:.25,bus:gust});
      addNoise({rate:.93,frequency:2600,gain:.0018,lfo:.21,depth:.0006,ceiling:4200,pan:-.3,bus:gust});
    } else if (this.stage === 'loggia') {
      addNoise({ frequency: 420, gain: 0.003, lfo: 0.041, depth: 0.001, ceiling: 1350 });
      addNoise({ rate: 0.81, type: 'lowpass', frequency: 180, gain: 0.005, lfo: 0.067, depth: 0.002 });
    } else if (this.stage === 'corsair') {
      addNoise({ type: 'lowpass', frequency: 450, gain: 0.016, lfo: 0.083, depth: 0.007, pan: 0.2 });
      addNoise({ rate: 0.83, frequency: 650, gain: 0.004, lfo: 0.047, depth: 0.0015, ceiling: 1500, pan: -0.2 });
    } else if (this.stage === 'sacred_grove') {
      addNoise({ frequency: 650, gain: 0.005, lfo: 0.055, depth: 0.002, ceiling: 1650 });
      // A distant stream, without the temple's invisible bell or scheduled bird.
      addNoise({ rate: 0.79, frequency: 1100, gain: 0.004, lfo: 0.11, depth: 0.001, ceiling: 2000, pan: 0.35 });
    } else if (this.stage === 'frozen_bay') {
      // Open inland ice: sparse dry air, without surf, storm or room echo.
      addNoise({ rate: 0.87, frequency: 520, gain: 0.0026, lfo: 0.037, depth: 0.0009, ceiling: 1500, pan: -0.15 });
      addNoise({ rate: 0.71, type: 'lowpass', frequency: 135, gain: 0.0035, lfo: 0.061, depth: 0.0011, ceiling: 750, pan: 0.12 });
    } else if (this.stage === 'qinglan') {
      // Clear noon: sparse leaves/awning air above a very distant river.
      // The near seep is represented only by its visible, scheduled drops.
      addNoise({ rate: 0.89, frequency: 1450, gain: 0.0014, lfo: 0.049, depth: 0.0005, ceiling: 2400, pan: -0.12 });
      addNoise({ rate: 0.73, frequency: 620, gain: 0.0018, lfo: 0.071, depth: 0.0003, ceiling: 1250, pan: 0.22 });
    } else if (this.stage === 'sluice') {
      // 잠든 습지: 낮게 흐르는 물 위에 눈에 보이는 잎·물방울 소리만 드문드문. 보이지 않는 빗소리·방 울림·동물 합창은 없다
      addNoise({ rate: 0.69, frequency: 920, gain: 0.0036, lfo: 0.075, depth: 0.0007, ceiling: 1700, pan: 0.3 });
      addNoise({ rate: 0.81, frequency: 470, gain: 0.0019, lfo: 0.043, depth: 0.0006, ceiling: 1350, pan: -0.16 });
      if(this.stageId==='sluice_night'){
        // Fine rain on water and leaves, softly spread across the stereo field.
        addNoise({rate:.91,frequency:2600,gain:.013,lfo:.087,depth:.0015,ceiling:5200,pan:-.45});
        addNoise({rate:.77,frequency:1800,gain:.010,lfo:.063,depth:.0012,ceiling:4300,pan:.45});
      }
    } else if (this.stage === 'dayr') {
      // 소금 사막: 그늘진 벽돌 문루를 지나는 마른 바람 두 겹 (샛별 값 그대로 — 우리 무대 바탕 가운데 가장 작다). 시장 소음·물소리 없음
      // Dry air through a shaded brick iwan. No surf or crowded market bed.
      addNoise({ rate: 0.81, frequency: 430, gain: 0.0017, lfo: 0.038, depth: 0.00065, ceiling: 1250, pan: 0.12 });
      addNoise({ rate: 0.69, frequency: 1100, gain: 0.00075, lfo: 0.061, depth: 0.0003, ceiling: 2100, pan: -0.2 });
    } else if (this.stage === 'etna') {
      // 화산섬: 해 뜨기 전 능선의 바람 두 겹 — 370 Hz 위 바람과 95 Hz 낮은 웅웅거림 (샛별 값 그대로). 불 굉음은 없다
      addNoise({ rate: 0.77, frequency: 370, gain: 0.0038, lfo: 0.031, depth: 0.0013, ceiling: 1250 });
      addNoise({ rate: 0.65, type: 'lowpass', frequency: 95, gain: 0.0020, lfo: 0.052, depth: 0.0007, ceiling: 420, pan: 0.3 });
    } else if (this.stage === 'dunhuang') {
      // 철불 절벽: 트인 절벽 앞 서늘하고 맑은 아침 — 옅게 움직이는 공기와 고운 모래 스침 두 겹 (샛별 값 그대로). 낮은 파도·비·불 울림·음 있는 드론·종소리 없음
      // Cool, clear morning at an open cliff: thin moving air and fine sand
      // friction, without low surf, rain, fire rumble or pitched drone.
      addNoise({ rate: 0.91, frequency: 760, gain: 0.0018, lfo: 0.043, depth: 0.0006, ceiling: 1900, pan: -0.18 });
      addNoise({ rate: 0.83, frequency: 2100, gain: 0.00065, lfo: 0.073, depth: 0.00025, ceiling: 3200, pan: 0.2 });
    }
    let remaining = nodes.length;
    for (const source of nodes) {
      source.onended = () => { if (--remaining === 0) for (const node of connections) node.disconnect(); };
      source.start(c.currentTime);
    }
    this.ambient = { out, nodes, detail: true, gust };
    return this.ambient;
  }

  /** 봉인의 중정 돌풍 (stage_courtyard.js 가 돌풍 시작에 보낸다): 바탕의 돌풍 겹을 돌풍 길이에 맞춰 키웠다 줄인다 — 세부음 목소리 · 간격 규칙과 따로 */
  gustSwell(data = {}) {
    const g = this.ambient?.gust, c = this.sound.ctx;
    const duration = Number.isFinite(data.duration) ? clamp(data.duration, 1, 8) : 4.6;
    if (!g || this.paused || !this.sound.on) { this.stats.rejected++; return false; }
    const t = c.currentTime, G = COURTYARD_GUST, peak = clamp(data.amp ?? 1, 0, 1) * (1 - G.low) + G.low;
    g.gain.cancelScheduledValues(t);
    g.gain.setTargetAtTime(peak, t, duration * G.rise);
    g.gain.setTargetAtTime(G.low, t + duration * G.fallAt, duration * G.fall);
    this.stats.gusts = (this.stats.gusts ?? 0) + 1;
    return true;
  }

  event(data = {}) {
    if (data.kind === 'courtyardGust') return this.stage === 'courtyard' ? this.gustSwell(data) : (this.stats.rejected++, false);
    const sound = this.sound, c = sound.ctx, profile = STAGE_DETAIL_PROFILES[data.kind];
    const reject = () => { this.stats.rejected++; return false; };
    if (!profile || profile.stage !== this.stage || !sound.on || this.paused || (!c.startRendering && c.state !== 'running')) return reject();
    if(profile.nightOnly&&this.stageId!=='sluice_night')return reject();
    if(this.stageId==='qinglan_night'&&data.kind==='cliffBird')return reject(); // 밤의 청람잔도엔 절벽 새가 울지 않는다 (stage_qinglan.js night)
    const amp = data.amp ?? 0.5;
    if (!Number.isFinite(amp) || amp <= 0 || (data.pos && !['x', 'y', 'z'].every((k) => Number.isFinite(data.pos[k])))) return reject();
    const t = c.currentTime;
    // A water drip just before the delayed rumble must not cancel its weather
    // cue. Keep the thunder's own spacing and the existing two-voice ceiling.
    const thunder = data.kind === 'wetlandThunder';
    if ((!thunder && t - this.lastAny < 2) || t - (this.last.get(data.kind) ?? -Infinity) < profile.gap || this.voices.size >= 2) return reject();
    const variant = thunder && Number.isInteger(data.variant) && data.variant >= 0 && data.variant < 3
      ? data.variant : (Number.isFinite(data.seed) ? Math.abs(data.seed | 0) : 0) % 3;
    const key = data.kind + ':' + variant;
    let buffer = this.buffers.get(key);
    if (!buffer) {
      const sr = 22050;
      const seed = 9127 + Object.keys(STAGE_DETAIL_PROFILES).indexOf(data.kind) * 311 + variant * 101;
      const pcm = synthStageDetail(data.kind, sr, this.makeRng(seed), variant);
      buffer = c.createBuffer(1, pcm.length, sr); buffer.getChannelData(0).set(pcm);
      this.buffers.set(key, buffer);
    }
    const source = c.createBufferSource(), gain = c.createGain();
    source.buffer = buffer;
    const where = sound._where(data.pos);
    const pan = Number.isFinite(where.pan) ? clamp(where.pan, -0.8, 0.8) : 0;
    const near = Number.isFinite(where.near) ? clamp(where.near, 0, 1.25) : 1;
    gain.gain.value = profile.gain * clamp(amp, 0, 1) * near;
    const nodes = [source, gain], panner = c.createStereoPanner?.();
    source.connect(gain);
    if (panner) { panner.pan.value = pan; gain.connect(panner).connect(sound.master); nodes.push(panner); }
    else gain.connect(sound.master);
    const voice = { source, gain, kind: data.kind, end: t + buffer.duration, nodes };
    this.voices.add(voice);
    source.onended = () => { this.voices.delete(voice); for (const node of nodes) node.disconnect(); this.stats.ended++; };
    source.start(t + 0.005);
    this.last.set(data.kind, t); this.lastAny = t;
    this.stats.accepted++;
    this.stats.peakVoices = Math.max(this.stats.peakVoices, this.voices.size);
    this.stats.last = { kind: data.kind, amp: clamp(amp, 0, 1), pan, near, gain: gain.gain.value, seed: variant, visualTime: Number.isFinite(data.time) ? data.time : null, audioTime: t };
    return true;
  }
}
