// 팔 호 계측 (R2′ 팔 단계, 10/8 사장님 "팔의 호가 머리를 싣게"): 대본 베기(chain_ledger script 장면과 같은 손 목표 경로, corr_lib FAM)에서
//  칼이 얻는 운동 에너지가 어디서 오나 — 손목 겨눔 토크(driveSword 가 칼에 직접 주는 τ·ω) / 손이 칼자루를 끌어 주는 몫(어깨·팔꿈치·몸통이
//  손을 움직인 일 = 나머지) / 중력.  dKE/dt = P_손목 + P_손 + P_중력 (상대 없음·접촉 없음). 획 창 = 손 목표가 움직이기 시작 → 칼끝 최고 속도.
//  손목 포화 = 창 안에서 |τ| ≥ 0.98·상한 인 스텝 비율. '손(팔 호)' 몫은 잔차다: 손 끌기 + 빈손 짝힘 + 비틀림 토크 + 칼 각감쇠(0.3) 가 들어간다. 결정적(고정 박자).
//  --held=1(기본) 손가락이 닿은 채(놀이 조건) · --v=6 손가락 빠르기 · --move=1 걸으며 · 선행 시간(골반·가슴·손 → 칼끝 최고)은 칼끝 최고 '이전' 창에서 잰다(손 최고치는 전체 창)
//  실행: node tools/sim/arm_arc_gauge.mjs [--weapons=longsword,morgenstern,zweihander] [--fams=diagR,vert,horizR] [--strokes=6] [--cap=22] [--stiff=60] [--move=0|1|-1] [--json]
import { newRound } from './harness_m.mjs';
import { DT, THREE, CONFIG } from './jelly_harness.mjs';
import { FAM } from './corr_lib.mjs';
import { getWeapon } from '../../src/weapons.js';
const args = Object.fromEntries(process.argv.slice(2).filter((a) => a.startsWith('--')).map((a) => { const [k, v] = a.slice(2).split('='); return [k, v ?? true]; }));
const weapons = String(args.weapons ?? 'longsword,morgenstern,zweihander').split(',');
const fams = String(args.fams ?? 'diagR,vert,horizR').split(',');
const STROKES = +(args.strokes ?? 6);
const CAP = args.cap != null ? +args.cap : null; // --cap=N : 시험할 무기들의 손목 토크 상한(weapons.js controlOverrides.maxAimTorque)을 이번 실행에만 바꾼다 (config WEAPON.maxAimTorque 는 무기표가 덮으므로 with_config 로는 안 바뀐다)
const STIFF = args.stiff != null ? +args.stiff : null; // --stiff=N : aimStiffness 도 같은 식
const MOVE = +(args.move ?? 0);
const VFING = args.v != null ? +args.v : null;
const HELD = args.held != null ? +args.held : 1; // --held=1(기본) 손가락이 닿은 채로(놀이처럼 handHeld: 보정 v2 쉼 무게 0) / 0 = 옛 대본(쉼 무게가 획 사이에 1 로 돌아감 — 10/8 03:50 전 표의 조건) // --v=6 : 손가락 빠르기(m/s) 덮어쓰기 (FAM.v 기본 12 — 사람 손가락은 6~8) // --move=1 앞으로 걸으며 벤다 / -1 뒤로 / 0 선 채 (P.move.y)
class Passive { update() {} }
const med = (a) => { const b = [...a].sort((x, y) => x - y); return b.length ? b[Math.floor(b.length / 2)] : NaN; };
const G_ACC = 9.81;
const _q = new THREE.Quaternion(), _f = new THREE.Quaternion(), _w = new THREE.Vector3();
function swordKE(sw) {
  const m = sw.mass(); const v = sw.linvel(); const w = sw.angvel(); const I = sw.principalInertia(); const f = sw.principalInertiaLocalFrame(); const r = sw.rotation();
  _q.set(r.x, r.y, r.z, r.w).multiply(_f.set(f.x, f.y, f.z, f.w)).invert();
  _w.set(w.x, w.y, w.z).applyQuaternion(_q);
  return 0.5 * m * (v.x * v.x + v.y * v.y + v.z * v.z) + 0.5 * (I.x * _w.x * _w.x + I.y * _w.y * _w.y + I.z * _w.z * _w.z);
}
const out = [];
for (const weapon of weapons) {
  const rows = []; let falls = 0, minPelY = 9;
  if (CAP != null) getWeapon(weapon).controlOverrides.maxAimTorque = CAP;
  if (STIFF != null) getWeapon(weapon).controlOverrides.aimStiffness = STIFF;
  for (const fam of fams) {
    const F = VFING ? { ...FAM[fam], v: VFING } : FAM[fam];
    const G = newRound({ walls: false, weapon, weapon2: 'longsword', seed: 7, AIClass: Passive }); const P = G.player; globalThis.__gaugeP = P;
    G.park(); P.skill.level = 0.7;
    P.handOffset.set(F.ch[0], F.ch[1]);
    for (let i = 0; i < Math.round(1.5 / DT); i++) { P.move.set(0, 0); G.step(); }
    if (HELD) P.handHeld = true;
    let tgt = F.end;
    for (let k = 0; k < STROKES; k++) {
      const from = [P.handOffset.x, P.handOffset.y];
      const dist = Math.hypot(tgt[0] - from[0], tgt[1] - from[1]);
      const n = Math.round((dist / F.v + 0.6) / DT);
      const sw = P.sword; const m = sw.mass();
      const ke0 = swordKE(sw);
      let Ew = 0, Eg = 0, sat = 0, steps = 0, tipMax = 0, iMax = 0, keMax = ke0, EwMax = 0, EgMax = 0, satMax = 0, tauMax = 0, capAt = 0, handMax = 0;
      const hsA = [], pwA = [], cwA = [], pwrA = [], brA = []; const pelB = P.bodies.pelvis, chB = P.bodies.chest; const _ht = new THREE.Vector3();
      const hb = P.bodies.farmS; const _hp = new THREE.Vector3(), _hq = new THREE.Quaternion();
      for (let i = 0; i < n; i++) {
        const off = P.handOffset;
        const dx = tgt[0] - off.x, dy = tgt[1] - off.y, d = Math.hypot(dx, dy), st = F.v * DT;
        if (d > st) { off.x += (dx / d) * st; off.y += (dy / d) * st; } else off.set(tgt[0], tgt[1]);
        P.move.set(0, MOVE);
        const w0 = sw.angvel(); const w0x = w0.x, w0y = w0.y, w0z = w0.z;
        G.step();
        const w = sw.angvel(); const v = sw.linvel();
        const tau = P.debug.wristTorque; const cap = P.debug.wristCap || 0;
        const pwr = (tau.x * (w0x + w.x) + tau.y * (w0y + w.y) + tau.z * (w0z + w.z)) * 0.5; Ew += pwr * DT; pwrA.push(pwr); brA.push(P.wristBrake ? 1 : 0); // 스텝 앞뒤 평균 ω (끝 ω 만 쓰면 τ·Δω·dt/2 만큼 부풀어 Et 의 3~10 % — 10/8 검토 5)
        Eg += -m * G_ACC * v.y * DT;
        steps++; if (cap > 0 && tau.length() >= 0.98 * cap) sat++;
        tauMax = Math.max(tauMax, tau.length()); capAt = cap;
        const hr = hb.rotation(), ht = hb.translation(); _hp.set(0.13, 0, 0).applyQuaternion(_hq.set(hr.x, hr.y, hr.z, hr.w)).add(_ht.set(ht.x, ht.y, ht.z));
        const hv = hb.velocityAtPoint({ x: _hp.x, y: _hp.y, z: _hp.z }); const hs = Math.hypot(hv.x, hv.y, hv.z); if (hs > handMax) handMax = hs;
        hsA.push(hs); pwA.push(Math.abs(pelB.angvel().y)); cwA.push(Math.abs(chB.angvel().y));
        if (P.state !== 'stand' && P.state !== 'kneel') falls++; minPelY = Math.min(minPelY, pelB.translation().y);
        const tip = P.tipVel.length();
        if (tip > tipMax) { tipMax = tip; iMax = i; keMax = swordKE(sw); EwMax = Ew; EgMax = Eg; satMax = sat / steps; }
      }
      const Et = keMax - ke0; const Eh = Et - EwMax - EgMax;
      const amax = (A) => { let b = 0; for (let j = 1; j <= iMax && j < A.length; j++) if (A[j] > A[b]) b = j; return b; }; // 칼끝 최고 '이전' 창의 최고 자리 (선행 시간용 — 10/8 검토 4)
      const iPel = amax(pwA), iCh = amax(cwA), iHand = amax(hsA); const pelW = pwA[iPel] ?? 0, chW = cwA[iCh] ?? 0;
      // WA3: 칼끝 최고 '이전' 창에서 손목이 제동(음의 일)한 몫과 제동 플래그가 처음 선 시각
      let EwNeg = 0, negSteps = 0; for (let j = 0; j <= iMax && j < pwrA.length; j++) if (pwrA[j] < 0) { EwNeg += pwrA[j] * DT; negSteps++; }
      let iBrake = -1; for (let j = 0; j < brA.length; j++) if (brA[j]) { iBrake = j; break; }
      rows.push({ weapon, fam, k, dir: tgt === F.end ? 'fwd' : 'back', tipMax: +tipMax.toFixed(2), tAcc: +((iMax + 1) * DT).toFixed(3), Et: +Et.toFixed(1), Ew: +EwMax.toFixed(1), Eh: +Eh.toFixed(1), Eg: +EgMax.toFixed(1), sat: +satMax.toFixed(2), tauMax: +tauMax.toFixed(1), cap: +capAt.toFixed(1), handMax: +handMax.toFixed(2), pelW: +pelW.toFixed(2), chW: +chW.toFixed(2), leadPel: +((iMax - iPel) * DT * 1000).toFixed(0), leadCh: +((iMax - iCh) * DT * 1000).toFixed(0), leadHand: +((iMax - iHand) * DT * 1000).toFixed(0), EwNeg: +EwNeg.toFixed(1), negFrac: +(negSteps / Math.max(1, iMax + 1)).toFixed(2), brakeLead: iBrake >= 0 ? +((iMax - iBrake) * DT * 1000).toFixed(0) : null });
      tgt = tgt === F.end ? F.ch : F.end;
    }
  }
  const sh = (r, k) => (r.Et > 1 ? r[k] / r.Et : NaN);
  const S = { weapon, n: rows.length, tipMax: med(rows.map((r) => r.tipMax)), tAcc: med(rows.map((r) => r.tAcc)), Et: med(rows.map((r) => r.Et)), wrist: med(rows.map((r) => sh(r, 'Ew'))), hand: med(rows.map((r) => sh(r, 'Eh'))), grav: med(rows.map((r) => sh(r, 'Eg'))), sat: med(rows.map((r) => r.sat)), tauMax: med(rows.map((r) => r.tauMax)), cap: med(rows.map((r) => r.cap)), handMax: med(rows.map((r) => r.handMax)), pelW: med(rows.map((r) => r.pelW)), chW: med(rows.map((r) => r.chW)), leadPel: med(rows.map((r) => r.leadPel)), leadCh: med(rows.map((r) => r.leadCh)), leadHand: med(rows.map((r) => r.leadHand)), EwNeg: med(rows.map((r) => r.EwNeg)), negFrac: med(rows.map((r) => r.negFrac)), brakeLead: med(rows.map((r) => r.brakeLead).filter((v) => v != null)), brakeN: rows.filter((r) => r.brakeLead != null).length };
  out.push({ summary: S, rows });
  console.log(`${weapon.padEnd(12)} 획 ${S.n}: 칼끝 최고 중앙 ${S.tipMax.toFixed(1)} m/s · 손 최고 ${S.handMax.toFixed(1)} m/s · 가속 ${(S.tAcc * 1000).toFixed(0)} ms · 얻은 KE ${S.Et.toFixed(0)} J · 몫 손목 ${(S.wrist * 100).toFixed(0)} % / 손(팔 호) ${(S.hand * 100).toFixed(0)} % / 중력 ${(S.grav * 100).toFixed(0)} % · 손목 포화 ${(S.sat * 100).toFixed(0)} % 스텝 · |τ| 최고 ${S.tauMax.toFixed(1)} / 상한 ${S.cap.toFixed(1)} N·m · 골반 ω ${S.pelW.toFixed(1)} · 가슴 ω ${S.chW.toFixed(1)} rad/s · 칼끝 최고보다 앞선 시간 골반 ${S.leadPel} / 가슴 ${S.leadCh} / 손 ${S.leadHand} ms · 서지 않은 스텝 ${falls} · 골반 최저 ${minPelY.toFixed(2)} m · [WA3] 칼끝 최고 전 손목 제동 일 ${S.EwNeg.toFixed(1)} J(음의 일 스텝 비율 ${(S.negFrac * 100).toFixed(0)} %) · 제동 플래그 시작 = 칼끝 최고 ${S.brakeLead >= 0 ? S.brakeLead + ' ms 전' : (-S.brakeLead) + ' ms 뒤'} (${S.brakeN}/${S.n} 획)`);
  { const Pq = globalThis.__gaugeP; if (Pq?.anchorYawN) console.log(`${''.padEnd(12)} [닻] yaw 요구 토크 최고 ${(Pq.anchorYawPeak || 0).toFixed(0)} N·m · 상한 ${CONFIG.BODY.anchorYawMax} 에 걸린 스텝 ${((100 * (Pq.anchorYawSat || 0)) / Pq.anchorYawN).toFixed(0)} % (서 있는 전 구간)`); } // 10/8 닻 토크 상한 실험
  if (args.json) console.log(JSON.stringify(rows));
}
