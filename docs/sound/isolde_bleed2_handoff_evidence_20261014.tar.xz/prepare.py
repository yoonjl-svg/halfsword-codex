from pathlib import Path
import subprocess,json,hashlib,numpy as np
from scipy.signal import correlate
p=Path('/tmp/halfsword-isolde-bleed2-20261014');out=p/'package';out.mkdir(exist_ok=True)
source=p/'mv855463-full-hq.mp3';sr=44100
sha=lambda x:hashlib.sha256(x).hexdigest()
def decode(file):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(file),'-ac','1','-ar',str(sr),'-f','f32le','-']),np.float32).copy()
source_info=json.loads((p/'source.json').read_text());rows=[]
for name,start,end,fadein,fadeout in [('isolde_bleed2_candidate',7.87,8.62,.035,.24),('isolde_short_exhale_reserve',.64,1.32,.025,.22)]:
 filters=f'atrim=start={start}:end={end},asetpts=PTS-STARTPTS,highpass=f=70,lowpass=f=6500'
 a=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(source),'-af',filters,'-ar',str(sr),'-ac','1','-f','f32le','-']),np.float32).copy()
 gain=.62/max(float(abs(a).max()),1e-9);a*=gain
 ni=round(fadein*sr);no=round(fadeout*sr);a[:ni]*=np.linspace(0,1,ni);a[-no:]*=np.linspace(1,0,no)
 f=out/(name+'.mp3');subprocess.run(['ffmpeg','-y','-v','error','-f','f32le','-ar',str(sr),'-ac','1','-i','-','-c:a','libmp3lame','-b:a','96k',str(f)],input=a.tobytes(),check=True)
 b=decode(f);assert np.isfinite(b).all() and abs(b).max()<.8
 thirds=[float(np.sqrt(np.mean(c*c))) for c in np.array_split(b,3)];assert thirds[0]>thirds[1]>thirds[2]
 comparisons=[]
 for old in Path('/workspace/halfsword-codex/public/sfx/voice').glob('isolde_*.mp3'):
  v=decode(old)[::3];q=b[::3];c=correlate(v,q,mode='full',method='fft');sim=float(abs(c).max()/np.sqrt(np.sum(v*v)*np.sum(q*q)))
  assert sim<.97
  comparisons.append({'file':old.name,'max_global_normalized_correlation':sim})
 rows.append({'file':f.name,'bytes':f.stat().st_size,'sha256':sha(f.read_bytes()),'source_id':855463,'source_interval_seconds':[start,end],'duration_seconds':len(b)/sr,'channels':1,'sample_rate':sr,'decoded_peak':float(abs(b).max()),'rms_thirds':thirds,'edits':{'highpass_hz':70,'lowpass_hz':6500,'gain_linear':gain,'fadein_seconds':fadein,'fadeout_seconds':fadeout,'pitch_tempo_changes':False},'existing_isolde_pcm_similarity':comparisons,'human_listening_approval':False})
(out/'mv855463-full-hq.mp3').write_bytes(source.read_bytes())
(p/'audio-checks.json').write_text(json.dumps({'pass':True,'source':source_info,'source_pcm_duration':len(decode(source))/sr,'candidates':rows},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'pass':True,'clips':[{k:r[k] for k in ['file','duration_seconds','decoded_peak','rms_thirds']} for r in rows]}))
