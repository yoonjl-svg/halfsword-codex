import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/cloud-onboarding/browser/node_modules/playwright/index.mjs';
const base=process.argv[2],out=process.argv[3],local=base.includes('127.0.0.1');
assert(base==='http://127.0.0.1:4182/' || base==='https://yoonjl-svg.github.io/halfsword-codex/');
const dir='/workspace/halfsword-codex/public/',prefix='transfers/isolde-source-20261013';
const paths=[prefix+'.zip',...['index.html','girl-damage-855460-hq.mp3','README.md','LICENSE.txt','manifest.json'].map(x=>prefix+'/'+x)];
const sha=b=>createHash('sha256').update(b).digest('hex');
const options={executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-background-networking']};
if(!local){const p=new URL(process.env.HTTPS_PROXY||process.env.https_proxy);options.proxy={server:p.protocol+'//'+p.host};if(p.username)options.proxy.username=decodeURIComponent(p.username);if(p.password)options.proxy.password=decodeURIComponent(p.password);}
let browser;const r={pass:false,local,files:[],errors:[],viewport:[390,844]};
try{browser=await chromium.launch(options);const ctx=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,serviceWorkers:'block'});
for(const name of paths){const res=await ctx.request.get(base+name);assert.equal(res.status(),200);const bytes=await res.body(),expected=await fs.readFile(dir+name);assert.equal(sha(bytes),sha(expected),name);r.files.push({name,bytes:bytes.length,sha256:sha(bytes)});}
const page=await ctx.newPage();page.on('pageerror',e=>r.errors.push(e.message));await page.goto(base+prefix+'/index.html');
await page.waitForFunction(()=>Number.isFinite(document.querySelector('audio')?.duration));
r.audio=await page.evaluate(async()=>{const a=document.querySelector('audio'),c=new AudioContext();const data=await(await fetch(a.src)).arrayBuffer(),b=await c.decodeAudioData(data);const v={metadataDuration:a.duration,decodedDuration:b.duration,channels:b.numberOfChannels,sampleRate:b.sampleRate};await c.close();return v;});
assert(Math.abs(r.audio.decodedDuration-9.322812)<.01);assert.equal(r.audio.channels,2);
for(const width of [320,390]){await page.setViewportSize({width,height:844});assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));}
await page.screenshot({path:out+'.png',fullPage:true});assert.deepEqual(r.errors,[]);r.pass=true;
}catch(e){r.failure=e.message;process.exitCode=1;}finally{if(browser)await browser.close();r.completedUTC=new Date().toISOString();await fs.writeFile(out+'.json',JSON.stringify(r,null,2));console.log(JSON.stringify({pass:r.pass,files:r.files.length,audio:r.audio,failure:r.failure}));}
