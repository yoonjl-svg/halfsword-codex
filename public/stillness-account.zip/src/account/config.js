// Set your own public project URL, publishable key and unique appId.
export default Object.freeze({ appId: 'halfsword-codex', url: '', publishableKey: '' });
